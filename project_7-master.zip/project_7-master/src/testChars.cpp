//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include <iostream>
#include "testChars.h"
#include "word.h"
#include "card.h"

using namespace std;

void CharsTester::RunTests() {
    testConstructWordWithCarriageReturn();
    testConstructWordWithNewLine();
    testIsWordValidWithSpace();
    testIsWordValidPercentSign();
    testIsWordValidShortWord();
    testConstructCardWithCarriageReturn();
    testConstructCardWithNewLine();
    testIsCardValidNoBlank();
    testIsCardValidShortBlank();
    testCorrectBlankLengthAndIndex();
    testCardIsLessThan();
}

/*
 * @requirement pass if "\r\n" is discarded by Word constructor
 * @return pass: true, fail: false
 */
bool CharsTester::testConstructWordWithCarriageReturn() {
	string testString = "word\r\n";

	Word testWord = Word(testString);

	if (testWord.GetContent() == "word") {
		return true;
	}
    return false;
}

/*
 * @requirement pass if "\n" is discarded by Word constructor
 * @return pass: true, fail: false
 */
bool CharsTester::testConstructWordWithNewLine() {
	string testString = "word\n";

	Word testWord = Word(testString);

	if (testWord.GetContent() == "word") {
		return true;
	}
	return false;
}

/*
 * @requirement pass if Word created using constructor with string that has a space is considered invalid
 * @return pass: true, fail: false
 */
bool CharsTester::testIsWordValidWithSpace() {
	string testString = "test word";

	Word testWord = Word(testString);

	if (!testWord.IsValid()) {
		return true;
	}
    return false;
}

/*
 * @requirement pass if Word created using constructor with string that has a percent sign is considered valid
 * @return pass: true, fail: false
 */
bool CharsTester::testIsWordValidPercentSign() {
	string testString = "percentage%";

	Word testWord = Word(testString);

	if (testWord.IsValid()) {
		return true;
	}
	return false;
}

/*
 * @requirement pass if Word created using constructor with string that is less than 3 characters is considered invalid
 * @return pass: true, fail: false
 */
bool CharsTester::testIsWordValidShortWord() {
	
	string testString = "hi";

	Word testWord = Word(testString);

	if (!testWord.IsValid()) {
		return true;
	}
	return false;
}

/*
 * @requirement pass if "\r\n" is discarded by Card constructor
 * @return pass: true, fail: false
 */
bool CharsTester::testConstructCardWithCarriageReturn() {
	string testLine = "this is a ____ card\r\n";

	Card testCard = Card(testLine);

	if (testCard.GetContent() == "this is a ____ card") {
		return true;
	}
    return false;
}

/*
 * @requirement pass if "\n" is discarded by Card constructor
 * @return pass: true, fail: false
 */
bool CharsTester::testConstructCardWithNewLine() {
	string testLine = "this is a ____ card\n";

	Card testCard = Card(testLine);

	if (testCard.GetContent() == "this is a ____ card") {
		return true;
	}
    return false;
}

/*
 * @requirement pass if Card created using constructor with string that has no underscores is invalid
 * @return pass: true, fail: false
 */
bool CharsTester::testIsCardValidNoBlank() {
	string testLine = "this is a card";

	Card testCard = Card(testLine);

	if (!testCard.IsValid()) {
		return true;
	}
	return false;
}

/*
 * @requirement pass if Card created using constructor with string that has a blank that is only two characters long is invalid
 * @return pass: true, fail: false
 */
bool CharsTester::testIsCardValidShortBlank() {
	string testLine = "this is a __ card";

	Card testCard = Card(testLine);

	if (!testCard.IsValid()) {
		return true;
	}
	return false;
}

/*
 * @requirement pass if blankLength and blankIndex is correct in properly formatted Card object with a blank yet to be filled.
 * @return pass: true, fail: false
 */
bool CharsTester::testCorrectBlankLengthAndIndex() {
	string testLine = "a ______ card";

	Card testCard = Card(testLine);

	if (testCard.GetBlankIndex() == 2 && testCard.GetBlankLength() == 6) {

		return true;
	}
    return false;
}

/*
 * @requirement pass if Card with contents that have fewer characters than another Card is considered "less than"
 * @return pass: true, fail: false
 */
bool CharsTester::testCardIsLessThan() {
	string testOne = "This is the _____ card.";
	string testTwo = "The ______ card.";

	Card cardOne = Card(testOne);
	Card cardTwo = Card(testTwo);

	if (cardTwo < cardOne) {
		return true;
	}
    return false;
}

