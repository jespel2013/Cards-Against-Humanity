//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include "testEndToEnd.h"
#include "chars.h"

using namespace std;

void EndToEndTester::RunTests(){
    for(int i = 1; i < 11; i++){
        if(testFile(i)) cout << "File " << i << " passed." << endl;
    }
}


/*
 * @requirement pass if all lines in files are the exact same AND output files can be opened properly
 * @return pass: 1, fail: 0
 */
bool EndToEndTester::testFile(int testNum){
	
	ifstream outStream;
	ifstream myOutStream;

	std::string testOutput;
	std::string myOutput;

	stringstream testWordsPath;
	stringstream testCardsPath;
	stringstream myOutputFilePath;
	stringstream testOutputFilePath;


	testWordsPath << TEST_FILE_RELATIVE_PATH << "/inputWords" << testNum + 1 << ".txt";
	testCardsPath << TEST_FILE_RELATIVE_PATH << "/inputCards" << testNum + 1 << ".txt";
	testOutputFilePath << TEST_FILE_RELATIVE_PATH << "/output" << testNum + 1 << ".txt";
	myOutputFilePath << TEST_FILE_RELATIVE_PATH << "/myoutput" << testNum + 1 << ".txt";
	
	Chars chars(testWordsPath.str(), testCardsPath.str(), myOutputFilePath.str());
    // read cards from the file
	chars.ReadCardsFromFile();
    // read words from the file
	chars.ReadWordsFromFile();
    // process the cards with the words
	chars.ProcessCards();
    // write the cards to the file
	chars.WriteCardsToFile();
    //check to see if any line is different
	outStream.open(testOutputFilePath.str());
	myOutStream.open(myOutputFilePath.str());
	if (!outStream.is_open()) {
		cout << "Output stream failed to open\n";
		return false;
	}
	if (!myOutStream.is_open()) {
		cout << "My output stream failed to open\n";
		return false;
	}

	while (!myOutStream.eof()) {
		getline(myOutStream, myOutput);
		getline(outStream, testOutput);

		if (myOutput != testOutput) {
			cout << "test Failed\n";
			myOutStream.close();
			outStream.close();
			return false;

		}

	}
	cout << "test passed" << endl;
	myOutStream.close();
	outStream.close();
    return true;
}
