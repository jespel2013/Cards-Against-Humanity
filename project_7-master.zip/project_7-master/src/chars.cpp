//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include <fstream>
#include <iostream>
#include <algorithm>
#include "word.h"
#include "chars.h"

using namespace std;

/**
 * Description: constructor for Chars
 *
 * @param string wordsFilePath relative path of file to get Word information
 * @param string cardsFilePath relative path of file to get Card information
 * @param string outputFilePath relative path of file to write processed cards information
 *
 * @requirement assign parameters to Chars data members of similar name
 */
Chars::Chars(std::string wordsFilePath, std::string cardsFilePath, std::string outputFilePath){
	_wordFilePath = wordsFilePath;
	_cardFilePath = cardsFilePath;
	_outputFilePath = outputFilePath;
	return;
}

/**
* Description: Read Cards from a File
*
*
* @requirement output error if _cardsFilePath cannot be opened
* @requirement populate _cards list in the order they are found in the file
* @requirement Every line in the _cardsFilePath is used to create a new Card object using the Card constructor
* @requirement A Card is added to the _cards list only if the Card is valid
* @requirement close the file stream when you are done.
*
*/
void Chars::ReadCardsFromFile() {
	ifstream inputFile;
	std::string tempString;

	inputFile.open(_cardFilePath);

	if (!inputFile.is_open()) {
		cout << "Error in opening" << _cardFilePath << endl;
	}
	else {
		while (!inputFile.eof()) {
			getline(inputFile, tempString);
			Card tempCard = Card(tempString);  //dynamic memory allocation??
			if (tempCard.IsValid()) {
				_cards.push_back(tempCard);
			}
		}
	}

	inputFile.close();

	return;


}

/**
 * Description: Read Word from a File
 *
 *
 * @requirement output error if _wordsFilePath cannot be opened
 * @requirement populate _words list in the order they are found in the file
 * @requirement Every line in the _wordsFilePath is used to create a new Word object using the Word constructor
 * @requirement A Word is added to the _words list only if the Word is valid
 * @requirement close the file stream when you are done.
 *
 */
void Chars::ReadWordsFromFile() {
	ifstream inputFile;
	std::string tempString;

	inputFile.open(_wordFilePath);

	if (!inputFile.is_open()) {
		cout << "Error in opening" << _wordFilePath << endl;
	}
	else {
		while (!inputFile.eof()) {
			getline(inputFile, tempString);
			Word tempWord = Word(tempString);  //dynamic memory allocation??
			if (tempWord.IsValid()) {
				_words.push_back(tempWord);
			}
		}
	}

	inputFile.close();
	return;
}

/**
 * Description: Uses _cards and _words lists to populate blanks inside of Card
 * objects in _cards with Word objects in _words
 *
 * @requirement attempt to fill all blanks in the Card objects in _cards with
 * the content of a Word object in _words with the same length as the blank
 * ReplaceBlanks should be used for replacing blanks
 *
 * @requirement If no Word object in _words is of the correct size for a Card object in _cards, then the Card object is removed from _cards using the erase function of the list<> type
 *
 * @requirement Once a Word in _words is used to replace a blank in a Card object in _cards, it is removed from _words using the erase function of the list<> type
 *
 */
void Chars::ProcessCards() {
	std::string wordStr;
	unsigned int wordFound = 0;

	

	for (std::list<Card>::iterator currCard = _cards.begin(); currCard != _cards.end(); currCard++) {
		Card tempCard = *currCard;
		wordFound = 0;

		for (std::list<Word>::iterator currWord = _words.begin(); currWord != _words.end(); currWord++) {
			wordStr = (*currWord).GetContent();
			Word tempWord(wordStr);

			if (tempCard.GetBlankLength() == wordStr.length()) {
				tempCard.ReplaceBlanks(tempWord);
				currCard->SetContent(tempCard.GetContent());
				wordFound = 1;
				_words.erase(currWord);
				break;
			}
		}
		if (wordFound == 0) {
			_cards.erase(currCard);  //returns "pointer" to next card
			currCard--; //accounts for this
		}
		
	}
	return;
}

/**
 * Description: Write Cards that have blanks filled with Words to _outputFilePath
 *
 * @requirement output error if _outputFilePath cannot be opened
 * @requirement The _cards list must be sorted according to the length of the card from shortest to longest.
 *
 * @requirement Each Card object in _cards must be output on a new line with a carriage return ("\r\n") at the end
 * @requirement close the file stream when you are done.
 *
 */
void Chars::WriteCardsToFile() {
	std::ofstream outFile; 
	

	outFile.open(_outputFilePath);

	if (!outFile.is_open()) {
		cout << "Output File not opened" << endl;
	}
	else {
		_cards.sort();
		for (std::list<Card>::iterator currCard = _cards.begin(); currCard != _cards.end(); currCard++) {
			outFile << (*currCard).GetContent() << "\r\n";
		}
	}

	outFile.close();
	return;
}
